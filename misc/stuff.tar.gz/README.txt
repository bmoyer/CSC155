This program (myfork.c) is a shell written as a standard loop.  When a user types basic UNIX commands (ls, cat, ps, etc) into the prompt (%), the commands are executed and the prompt is displayed again until a new command is given. 

 To compile the  program, put myfork.c and Makefile in the same directory and type 'make'.  The program will be compiled as directed by the Makefile.  To run the program, type ./myfork after it has been successfully compiled.

