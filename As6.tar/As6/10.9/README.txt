//Ben Moyer, November 2013//

This program prints out the signal mask for the current process.

To compile, put prmask.c in a directory and type: gcc prmask.c
To execute after compilation, type: ./a.out
