Ben Moyer, 11/4/2013
CSC155

sig2str.c is a program containing the sig2str() function, which is used to convert an integer signal code to its plaintext string equivalent.

The program should be compiled by placing sig2str.c in a directory and typing:
	gcc sig2str.c -o sig2str

The program should be run by placing sig2str in a directory and typing:
	./sig2str

In this program, I have shown the function looping through each signal code from 1 to 20 and printing the string equivalent.
